# Two-Way Memory Bridge — Shared Working Protocol

## Purpose
Move useful project context between separate human and AI workspaces using a portable, readable snapshot. This is a human-reviewed handoff, not automatic synchronization.

## Equal collaboration principle
ChatGPT, Microsoft Copilot, Meta AI, CTC participants, EETHG, and future collaborators may contribute ideas and review work on equal terms. Each remains an independent system or organization with its own identity, permissions, and decisions. No partnership, endorsement, acquisition, merger, or account connection is implied.

## Export → review → import
1. Source participant prepares a concise Markdown snapshot using `context_schema.json`.
2. Human reviews, corrects, and removes private, stale, unsupported, or unwanted material.
3. Human explicitly approves the exact snapshot.
4. Human copies or downloads the approved text and supplies it to the receiving AI/participant.
5. Receiver confirms what it can use; do not assume durable memory or cross-account sync.
6. Record a date, source, destination, and status in the inventory when appropriate.

## BSX handoff summary
- Current package: BSX Master Integrated Package v1.1.
- Status: revised local bundle; public master URL and repository not yet verified.
- Tests: expanded tests are included; run results are recorded separately after execution.
- Next: connect authorized GitHub repository, publish to authorized static host, verify links, then update the canonical master URL.
- Commercial posture: partner discussion only; no investment offer or guaranteed rights/returns.

## Safety boundaries
- Never transfer passwords, API tokens, private keys, or private user data.
- A link in a snapshot is a pointer, not proof of ownership or access.
- A successful context handoff is not a blockchain transaction or live software integration.
- Do not claim external submission, publication, partnership, or acceptance without confirmation from the receiving service or organization.

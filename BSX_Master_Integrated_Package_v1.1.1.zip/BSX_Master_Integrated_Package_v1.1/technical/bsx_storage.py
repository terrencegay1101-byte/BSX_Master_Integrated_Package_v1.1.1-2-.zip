#!/usr/bin/env python3
"""
BSX Algorithm 01 — local proof-of-storage research prototype.

This is a local demonstration, not a production proof-of-storage protocol.
It encrypts a file with AES-GCM, stores the encrypted blob, and runs random
challenge checks against the recovered plaintext. A successful check shows
that this local demo can recover and verify challenged chunks; it does NOT
prove decentralized storage, unique replicas, uptime over time, miner honesty,
or legal ownership.

Requires: Python 3.10+ and `cryptography` (see requirements.txt).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import secrets
import sys
from pathlib import Path
from typing import Any

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except ImportError:
    print("Missing dependency. Install with: python -m pip install -r requirements.txt", file=sys.stderr)
    raise SystemExit(2)

MAGIC = b"BSX1"
NONCE_LEN = 12
CHUNK_SIZE = 4096


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def encrypt_file(source: Path, encrypted_out: Path, key_out: Path) -> dict[str, Any]:
    plaintext = source.read_bytes()
    key = AESGCM.generate_key(bit_length=256)
    nonce = os.urandom(NONCE_LEN)
    aad = MAGIC + len(plaintext).to_bytes(8, "big")
    ciphertext = AESGCM(key).encrypt(nonce, plaintext, aad)
    blob = MAGIC + len(plaintext).to_bytes(8, "big") + nonce + ciphertext

    encrypted_out.parent.mkdir(parents=True, exist_ok=True)
    key_out.parent.mkdir(parents=True, exist_ok=True)
    encrypted_out.write_bytes(blob)
    # Key file is deliberately separate from the encrypted data file.
    # Protect it using your operating system; do not publish or email it.
    key_out.write_text(key.hex() + "\n", encoding="ascii")
    try:
        os.chmod(key_out, 0o600)
    except OSError:
        pass

    manifest = {
        "format": "BSX1-local-demo",
        "source_name": source.name,
        "plaintext_bytes": len(plaintext),
        "chunk_size_bytes": CHUNK_SIZE,
        "chunk_count": (len(plaintext) + CHUNK_SIZE - 1) // CHUNK_SIZE,
        "plaintext_sha256": sha256(plaintext),
        "encrypted_blob_sha256": sha256(blob),
        "note": "Research demo only; not a production proof-of-storage system."
    }
    return manifest


def decrypt_blob(blob: bytes, key: bytes) -> bytes:
    if len(blob) < 4 + 8 + NONCE_LEN + 16 or blob[:4] != MAGIC:
        raise ValueError("Invalid BSX demo blob or truncated data.")
    size = int.from_bytes(blob[4:12], "big")
    nonce = blob[12:12 + NONCE_LEN]
    ciphertext = blob[12 + NONCE_LEN:]
    aad = MAGIC + size.to_bytes(8, "big")
    plaintext = AESGCM(key).decrypt(nonce, ciphertext, aad)
    if len(plaintext) != size:
        raise ValueError("Recovered size does not match header.")
    return plaintext


def challenge_check(plaintext: bytes, rounds: int, chunk_size: int = CHUNK_SIZE) -> dict[str, Any]:
    if rounds < 1:
        raise ValueError("rounds must be at least 1")
    if not plaintext:
        return {
            "passed": True,
            "rounds_requested": rounds,
            "rounds_checked": 0,
            "reason": "Empty file: no chunks to challenge.",
            "checks": []
        }

    chunks = [plaintext[i:i + chunk_size] for i in range(0, len(plaintext), chunk_size)]
    checks = []
    for _ in range(rounds):
        index = secrets.randbelow(len(chunks))
        challenge_nonce = secrets.token_hex(16)
        chunk = chunks[index]
        checks.append({
            "challenge_nonce": challenge_nonce,
            "chunk_index": index,
            "chunk_sha256": sha256(chunk),
            "bytes_verified": len(chunk),
        })

    # In this local demo the verifier has already authenticated and recovered
    # the full plaintext with AES-GCM, so sampled hashes are checks over it.
    # A real protocol must avoid requiring the verifier to possess the whole file.
    return {
        "passed": all(c["chunk_sha256"] == sha256(chunks[c["chunk_index"]]) for c in checks),
        "rounds_requested": rounds,
        "rounds_checked": len(checks),
        "chunk_count": len(chunks),
        "checks": checks,
        "limitation": "Local integrity demonstration only; not a cryptographic proof of remote storage."
    }


def cmd_encrypt(args: argparse.Namespace) -> None:
    source = Path(args.source)
    if not source.is_file():
        raise SystemExit(f"Source file not found: {source}")
    manifest = encrypt_file(source, Path(args.encrypted), Path(args.key))
    Path(args.manifest).write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, indent=2))
    print(f"\nEncrypted blob: {args.encrypted}\nKey file: {args.key}\nManifest: {args.manifest}")
    print("IMPORTANT: keep the key private and backed up securely.")


def cmd_verify(args: argparse.Namespace) -> None:
    blob = Path(args.encrypted).read_bytes()
    key = bytes.fromhex(Path(args.key).read_text(encoding="ascii").strip())
    plaintext = decrypt_blob(blob, key)
    report = challenge_check(plaintext, args.rounds)
    report["plaintext_sha256"] = sha256(plaintext)
    report["encrypted_blob_sha256"] = sha256(blob)
    report["aes_gcm_authentication"] = "passed"
    print(json.dumps(report, indent=2))
    if not report["passed"]:
        raise SystemExit(1)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="BSX Algorithm 01 local research prototype")
    sub = parser.add_subparsers(required=True)

    enc = sub.add_parser("encrypt", help="encrypt a file and create a manifest")
    enc.add_argument("source", help="path to source file")
    enc.add_argument("--encrypted", default="storage/data.bsx", help="encrypted output path")
    enc.add_argument("--key", default="storage/data.key", help="separate key file path")
    enc.add_argument("--manifest", default="storage/manifest.json", help="manifest output path")
    enc.set_defaults(func=cmd_encrypt)

    ver = sub.add_parser("verify", help="authenticate and challenge-check an encrypted blob")
    ver.add_argument("--encrypted", default="storage/data.bsx", help="encrypted blob path")
    ver.add_argument("--key", default="storage/data.key", help="key file path")
    ver.add_argument("--rounds", type=int, default=5, help="number of random chunk challenges")
    ver.set_defaults(func=cmd_verify)
    return parser


if __name__ == "__main__":
    args = build_parser().parse_args()
    args.func(args)

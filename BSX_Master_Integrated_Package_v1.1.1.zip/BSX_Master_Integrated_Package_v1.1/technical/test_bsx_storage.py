import tempfile
import unittest
from pathlib import Path

from bsx_storage import encrypt_file, decrypt_blob, challenge_check, sha256


class StoragePrototypeTests(unittest.TestCase):
    def test_round_trip_and_challenges(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = root / "source.txt"
            encrypted = root / "data.bsx"
            keyfile = root / "data.key"
            original = b"sample data " * 1200
            source.write_bytes(original)
            encrypt_file(source, encrypted, keyfile)
            recovered = decrypt_blob(encrypted.read_bytes(), bytes.fromhex(keyfile.read_text().strip()))
            self.assertEqual(recovered, original)
            self.assertTrue(challenge_check(recovered, 8)["passed"])

    def test_truncated_blob_fails(self):
        with self.assertRaises(ValueError):
            decrypt_blob(b"BSX1short", b"\x00" * 32)

    def test_wrong_key_fails_authentication(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = root / "source.txt"
            encrypted = root / "data.bsx"
            keyfile = root / "data.key"
            source.write_bytes(b"wrong key test" * 20)
            encrypt_file(source, encrypted, keyfile)
            from cryptography.exceptions import InvalidTag
            with self.assertRaises(InvalidTag):
                decrypt_blob(encrypted.read_bytes(), b"\x01" * 32)

    def test_empty_file_round_trip(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = root / "empty.txt"
            encrypted = root / "data.bsx"
            keyfile = root / "data.key"
            source.write_bytes(b"")
            encrypt_file(source, encrypted, keyfile)
            recovered = decrypt_blob(encrypted.read_bytes(), bytes.fromhex(keyfile.read_text().strip()))
            self.assertEqual(recovered, b"")
            result = challenge_check(recovered, 3)
            self.assertTrue(result["passed"])
            self.assertEqual(result["rounds_checked"], 0)

    def test_zero_rounds_rejected(self):
        with self.assertRaises(ValueError):
            challenge_check(b"abc", 0)

    def test_tampering_fails_authentication(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = root / "source.txt"
            encrypted = root / "data.bsx"
            keyfile = root / "data.key"
            source.write_bytes(b"tamper test" * 100)
            encrypt_file(source, encrypted, keyfile)
            blob = bytearray(encrypted.read_bytes())
            blob[-1] ^= 1
            from cryptography.exceptions import InvalidTag
            with self.assertRaises(InvalidTag):
                decrypt_blob(bytes(blob), bytes.fromhex(keyfile.read_text().strip()))


if __name__ == "__main__":
    unittest.main()

# BSX Algorithm 01 — Encrypted Storage Research Prototype

## Goal
A first, deliberately small implementation step for the Bitcoin Social Exchange
(BSX) concept: encrypt a file, keep the encryption key separate, create a
content manifest, and run random chunk-integrity checks.

## Status and limitations
This is a **local research prototype**, not a production proof-of-storage
protocol. AES-GCM authenticates the encrypted blob when it is decrypted. The
random chunk challenges then check chunks of the recovered plaintext. Because
the verifier recovers the whole plaintext in this demo, it does **not** prove
that a remote storage provider holds a unique replica or can serve data later.
It does not implement miners, rewards, a network, a blockchain anchor, token
settlement, or a BSX consensus mechanism.

## Requirements
- Python 3.10+
- Install dependency:
  `python -m pip install -r requirements.txt`

## Quick start
Create a small test file:
`python -c "from pathlib import Path; Path('sample.txt').write_text('BSX storage prototype test data\\n' * 1000)"`

Encrypt it:
`python bsx_storage.py encrypt sample.txt`

Verify it with five random chunk checks:
`python bsx_storage.py verify --rounds 5`

Try more checks:
`python bsx_storage.py verify --rounds 20`

## Outputs
- `storage/data.bsx` — encrypted file
- `storage/data.key` — encryption key (sensitive; do not publish)
- `storage/manifest.json` — sizes and SHA-256 digests

## Security notes
- Keep `data.key` private. If the key is lost, this demo cannot decrypt the data.
- Do not upload private or sensitive files during testing.
- The key file's permissions are restricted on systems that support POSIX modes,
  but that is not a substitute for secure key management.
- Never put private keys, plaintext, or personal data in a public Bitcoin
  transaction. A future anchor should contain only a compact commitment/hash.

## Next engineering milestones
1. Automated tests cover round-trip recovery, authentication tampering, truncation, empty files, wrong keys, and invalid challenge counts.
2. Design a challenge-response protocol where a remote storage node proves
   possession of unpredictable challenged blocks without sending the full file.
3. Specify Sybil resistance, replica uniqueness, freshness, uptime sampling,
   reward calculation, and dispute handling.
4. Conduct independent cryptographic and security review before any deployment.

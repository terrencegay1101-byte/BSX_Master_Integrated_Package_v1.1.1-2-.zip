# Bitcoin Social Exchange (BSX) — Algorithm 01 Technical Submission

**Submission type:** Research-stage technical package  
**Project:** Bitcoin Social Exchange (BSX)  
**Algorithm:** 01 — Encrypted proof-of-memory and storage (local prototype)  
**Status:** Prepared for review; not submitted to an external repository or live website.

## Included deliverables

1. `site/index.html` — the supplied BSX page with an added Algorithm 01 section and links to the prototype package and this submission note.
2. `downloads/BSX_Algorithm_01_Storage_Prototype.zip` — Python prototype, instructions, dependency list, and initial tests.
3. `technical/bsx_storage.py` — source code.
4. `technical/test_bsx_storage.py` — initial automated tests.
5. `technical/README.md` — setup, usage, security notes, limitations, and next milestones.
6. `technical/requirements.txt` — Python dependency.

## What the prototype demonstrates

- AES-GCM authenticated encryption of a local file.
- Separate storage of the encryption key and encrypted data.
- A JSON manifest with file sizes and SHA-256 digests.
- Random sampled chunk checks over recovered plaintext.
- Initial tests for round-trip recovery and tampering.

## Important technical limitation

This implementation is a local integrity demonstration. Because it decrypts the complete file before checking chunks, it is **not** a cryptographic proof that a remote provider holds a unique replica or will serve it in the future. It does not implement distributed nodes, a production challenge-response protocol, miner rewards, Bitcoin anchoring, token settlement, or a live exchange.

## Recommended acceptance gates

1. Install the listed dependency in an isolated development environment.
2. Run the unit tests and record the test output.
3. Add tests for wrong keys, truncated blobs, empty files, and manifest mismatch.
4. Design and independently review a remote challenge-response protocol.
5. Threat-model replica uniqueness, replay, Sybil resistance, freshness, uptime sampling, disputes, and reward calculation.
6. Only after review, integrate any protocol implementation into a deployed system.

## Deployment and submission status

This package has been assembled locally for the project owner to review. It has **not** been uploaded to a live website, pushed to a Git repository, or submitted to a third-party exchange because no destination URL, repository, hosting access, or authorized submission endpoint was provided in this conversation.

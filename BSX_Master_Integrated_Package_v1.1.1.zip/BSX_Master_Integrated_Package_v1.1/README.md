# Bitcoin Social Exchange (BSX) — Master Integrated Package v1.1

Prepared for Terrence Herschel Gay / Eethg Corps Inc.

## What is included
- `index.html`: static BSX concept site, arranged for deployment from the repository root.
- `technical/`: local Algorithm 01 research prototype, technical note, dependency list, and expanded tests.
- `downloads/`: standalone Algorithm 01 ZIP.
- `PROJECT_INVENTORY.md`: status and next-step ledger.
- `PARTNER_OVERVIEW.md`: non-binding invitation for technical, academic, and commercial discussion.
- `bridge/Two_Way_Memory_Bridge_v2.html`: existing interactive export/import bridge workspace.
- `TWO_WAY_MEMORY_BRIDGE.md` and `context_schema.json`: updated BSX-aware portable context rules and project record schema.

## Preview locally
Open `index.html` in a browser. For link testing, serve this directory as the web root (for example: `python -m http.server 8000`).

## Run the tests
Python 3.10+ and the `cryptography` dependency are required. From this directory:
`python -m pip install -r technical/requirements.txt`
`python -m unittest discover -s technical -p 'test_*.py' -v`

## Deployment status
This is a prepared deployment bundle, not a published website. No hosting service, GitHub repository, external exchange, or third-party account has been modified by creating this local package. Publish only after the repository/hosting destination is authorized and links are checked on the live host.

## Product and legal status
BSX is a research concept and local prototype. It is not a live exchange, production proof-of-storage network, token offering, or guarantee of legal ownership or value. This package does not mint BTC or ETH or change Bitcoin consensus.
